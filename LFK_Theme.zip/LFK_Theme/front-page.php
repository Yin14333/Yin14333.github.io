<?php
    get_header();
?>

        <!-- Page Content  -->
        <div id="content">

            <header>
                <div id="header-img">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/logo.png" alt="header picture" class="img-fluid">
                </div>
            </header>

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn custom-hamburger">
                        <i class="fas fa-align-left"></i>
                        <span></span>
                    </button>
                    
                    <button onclick="location.href = '#en-text';" class="btn custom-jump" id="jump-button">Jump To English</button>
                </div>
                
            </nav>

        <article>
            <?php 
                // Start the loop
                if ( have_posts() ) : while ( have_posts() ) : the_post();
            ?>

            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            <p><?php the_content(); ?></p>

            <?php 
                // End the loop
                endwhile; else : 
            ?>

            <p><?php _e( 'Sorry, no pages found.' ); ?></p>

            <?php endif; ?>


        </article>
            

    <?php 
        wp_footer();
    ?>

</body>

</html>