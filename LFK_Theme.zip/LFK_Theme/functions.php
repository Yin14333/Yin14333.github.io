<?php

    function lfk_theme_support() {
        add_theme_support( 'title-tag' );
        add_theme_support( 'post-thumbnails' );
    }

    add_action( 'after_setup_theme', 'lfk_theme_support' );

    function lfk_menus() {
        $locations = array(
            'primary' => "Desktop Primary Left Sidebar",
            'footer' => "Footer Menu Items"
        );

        register_nav_menus( $locations );
    }

    add_action( 'init', 'lfk_menus' );

    function lfk_register_styles() {
        $version = wp_get_theme()->get( 'Version' );
        wp_enqueue_style( 'lfk-style', get_template_directory_uri() . "/style.css", array('lfk-bootstrap'), $version, 'all' );
        wp_enqueue_style( 'lfk-bootstrap', "https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css", array(), $version, 'all' );
        wp_enqueue_style( 'scrollbar-style', "https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css", array(), $version, 'all' );
    }

    add_action( 'wp_enqueue_scripts', 'lfk_register_styles' );

    function lfk_register_script() {
        wp_enqueue_script( 'lfk-jquery', "https://code.jquery.com/jquery-3.3.1.slim.min.js", array(), '3.3.1', true );
        wp_enqueue_script( 'lfk-popper', "https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js", array(), '1.14.0', true );
        wp_enqueue_script( 'font-awsome1', "https://use.fontawesome.com/releases/v5.0.13/js/solid.js", array(), '3.3.1', true );
        wp_enqueue_script( 'font-awsome2', "https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js", array(), '1.14.0', true );
        wp_enqueue_script( 'lfk-bootstrap', "https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js", array(), '4.1.0', true );
        wp_enqueue_script( 'scrollbar-script', "https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js", array(), '3.1.5', true );
        wp_enqueue_script( 'lfk-main', get_template_directory_uri() . "/assets/js/main.js", array(), '1.0', true );
    }

    add_action( 'wp_enqueue_scripts', 'lfk_register_script' );


?>