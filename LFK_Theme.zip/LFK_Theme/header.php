<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Collapsible sidebar using Bootstrap 4</title>

 
    <?php wp_head(); ?>

</head>

<body>

    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <!--Searchbar-->
                <div class="input-group">
                    <input type="search" class="form-control rounded" placeholder="Search/搜索" aria-label="Search" aria-describedby="search-addon" />
                    <button type="button" class="btn search-btn"><i class="fas fa-search"></i></button>
                  </div>
            </div>

            <?php

               wp_nav_menu( array(
                  'menu' => 'primary',
                  'theme_location' => 'primary',
                   
    
               ) );
             
            ?>

        


            <ul class="list-unstyled components">
                <li class="active">
                    <li>
                        <a href="#" class = "major-heading">Li Fang-Kuei Society <br>李方桂研究學會</a>
                    </li>
                    <li>
                        <a href="#">Our Work 學會工作</a>
                    </li>
                    <li>
                        <a href="#">Our Organization 學會組織</a>
                    </li>
                </li>
                <li>
                    <a href="#BCLmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">BCL 中國語言學集刊</a>
                    <ul class="collapse list-unstyled" id="BCLmenu">
                        <li>
                            <a href="#">About BCL 中國語言學集刊</a>
                        </li>
                        <li>
                            <a href="#">Preface 發刊詞</a>
                        </li>
                        <li>
                            <a href="#">Table of Contents of BCL 目錄</a>
                        </li>
                        <li>
                            <a href="#">BCL Style Sheet 投稿格式</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#">Awards for Services 服務貢獻獎</a>
                </li>
                <li>
                    <a href="#Awardmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">LFK Awards and Grant<br>學會獎項及補助</a>
                    <ul class="collapse list-unstyled" id="Awardmenu">
                        <li>
                            <a href="#">Li Fang-Kuei Book Awards 李方桂語言學論著獎</a>
                        </li>
                        <li>
                            <a href="#">LFK Field Work Award 李方桂田野調查獎</a>
                        </li>
                        <li>
                            <a href="#">LFK Dissertation Award 李方桂博士論文獎</a>
                        </li>
                        <li>
                            <a href="#">LFK Graduate Student 李方桂研究生學術會議旅費補助</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#Activitymenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Activities 學會活動</a>
                    <ul class="collapse list-unstyled" id="Activitymenu">
                        <li>
                            <a href="#">2006 Int'l Conference 2006年國際學術會議 </a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#YSmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Young Scholars Symposium <br> 青年學者研討會 </a>
                    <ul class="collapse list-unstyled" id="YSmenu">
                        <li>
                            <a href="#">Young Scholars 青年學者研討會</a>
                        </li>
                        <li>
                            <a href="#">2013 YS Symposium 2013 青年學者研討會</a>
                        </li>
                        <li>
                            <a href="#">2018 YS Symposium 2018 青年學者研討會</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#Supportmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Appeal for Support 籲請支持</a>
                    <ul class="collapse list-unstyled" id="Supportmenu">
                        <li>
                            <a href="#">Sollicitation Letter 募捐信</a>
                        </li>
                        <li>
                            <a href="#">Donors 贊助人名單</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#" class = "major-heading">About PROF. LI FANG-KUEI <br>關於李方桂先生</a>
                </li>
                <li>
                    <a href="#SWorkmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Scholarly Work 李方桂先生業績</a>
                    <ul class="collapse list-unstyled" id="SWorkmenu">
                        <li>
                            <a href="#">Father of Non-Chinese Linguistics 「非漢語」語言學之父</a>
                        </li>
                        <li>
                            <a href="#">Bibliography of Prof.Li 李方桂先生著作目錄</a>
                        </li>
                        <li>
                            <a href="#">Preface of Collections of Essays 《李方桂全集》總序</a>
                        </li>
                        <li>
                            <a href="#">Papers in BIHP 《史語所集刊》文章</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#SeminalWmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Seminal Works 李方桂先生代表作</a>
                    <ul class="collapse list-unstyled" id="SeminalWmenu">
                        <li>
                            <a href="#">Final Consonants in Old Chinese 論韻尾輔音</a>
                        </li>
                        <li>
                            <a href="#">Phonology of Old Chinese 上古音韻表</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#Aboutmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">About Prof.Li 李方桂先生其人其事</a>
                    <ul class="collapse list-unstyled" id="Aboutmenu">
                        <li>
                            <a href="#">Manuscripts 李方桂先生手跡</a>
                        </li>
                        <li>
                            <a href="#">Paintings 李方桂先生畫冊</a>
                        </li>
                        <li>
                            <a href="#">Vignettes of My Father 在一個涼爽的地方</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#Memorymenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">To His Memory 紀念李方桂先生</a>
                    <ul class="collapse list-unstyled" id="Memorymenu">
                        <li>
                            <a href="#">Pang-Hsin Ting 丁邦新文</a>
                        </li>
                        <li>
                            <a href="#">South Coblin 柯蔚南文</a>
                        </li>
                        <li>
                            <a href="#">In Memoriam | UW 1987 追悼會 | 1987</a>
                        </li>
                        <li>
                            <a href="#">1998 Int'l Symposium 1998年學者研討會</a>
                        </li>
                        <li>
                            <a href="#">2002 Int'l Symposium 2002年學者研討會</a>
                        </li>
                    </ul>
                </li>
                <li>
                <a href="#Prof.Ding" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">Announcements 通告</a>
                    <ul class="collapse list-unstyled" id="Prof.Ding">
                        <li>
                            <a href="#">Obituary 訃聞</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#" class = "major-heading">CONTACT US 聯繫我們</a>
                </li>
            </ul>
        </nav>

    </div>