<div class="footer">
    <div id="footerText">
        <a href="#">PO Box 45823, Seattle, WA 98145-0823</a>
    </div>
</div>
